
$(document).ready(function(){

	
load("0")


//console.log(JSON.stringify({
//"name": "User Surname",
//"cpf": "12312312312",
//"phone": "11983553433",
//"email": "phyato1@teste.com",
//"birthdate": "1988-08-10",
//"accept_whatsapp": false,
//"accept_news": false,
//"accept_regulation": true,
//"password": "123456",
//"password_confirmation": "123456"
//}))
	
if(window.location.hash == "#logar") {
	//alert(window.location.hash)


	$(".search-popup.py-orange").addClass("open")


} else {
  // Fragment doesn't exist
}
	
	$('#accept_whatsapp').change(function(){
        if($("#accept_whatsapp").prop('checked')){
            $("#accept_whatsapp").attr('value', 'true');
        }else{
            $("#accept_whatsapp").attr('value', 'false');
        }
    });


	$('#accept_news').change(function(){
        if($("#accept_news").prop('checked')){
            $("#accept_news").attr('value', 'true');
        }else{
            $("#accept_news").attr('value', 'false');
        }
    });


	$('#accept_regulation').change(function(){
        if($("#accept_regulation").prop('checked')){
            $("#accept_regulation").attr('value', 'true');
        }else{
            $("#accept_regulation").attr('value', 'false');
        }
    });


	
$("form#cadastro").submit(function(){
	load("1");
	var th = $(this).serialize();
		
		var dados = $(this).serializeObject();
		//var dados =JSON.stringify({
		//name: "teste 2",
		//cpf: "72730860029",
		//phone: "11878765432",
		//email: "teste2@taste.com",
		//birthdate: "1988-08-10",
		//accept_whatsapp: "false",
		//accept_news: "false",
		//accept_regulation: "true",
		//password: "123456",
		//password_confirmation: "123456"
		//})
		
		//console.log(dados);
		
		//console.log(JSON.stringify(dados));
	//	return false;
		$.ajax({
			url: 'http://meumomentophyto.com.br/api/participants',
			contentType: 'application/json',
			cache: false,
			method: 'POST',
			dataType: 'json',
			data:JSON.stringify(dados),
			success: function(data) {
				load("0");
				alertar("Parabéns!","Seu cadastro foi realizado com sucesso","success","cadastrar.html#logar");
				
				$(".search-popup.py-orange").addClass("open")


				window.location.href="cadastrar.html#logar"
			}
		});

		
		return false;
	})

	
	
	
$("form#login").submit(function(){

		var dados = $(this).serializeObject();
		
		//console.log(dados);
		
		//console.log(JSON.stringify(dados));
		//setCookie("aa","aa");
	
		load("1");
	
	if(getCookie("token")!=""){

			window.location.href="interna";
		
	}else{
		
			$.ajax({
				url: 'http://meumomentophyto.com.br/api/sessions',
				contentType: 'application/json',
				cache: false,
				method: 'POST',
				dataType: 'json',
				data:JSON.stringify(dados),
				success: function(data) {
					
					

				/*	aniversario = data.participant.birthdate,
					CPF 		= data.participant.cpf,
					criado = data.participant.created_at,
					email = data.participant.email,
					id = data.participant.id,
					nome = data.participant.name,
					fone = data.participant.phone,
					registrado = data.participant.register_source,
					
					pass = data.participant.password,*/
					var stts = data.participant.status,
						token = data.token;

					
					
					setCookie("dados",JSON.stringify(data.participant));	
					
					setCookie("token",token);
					
					
					

						if(token !="" && stts == true){
							//alert(1);
							window.location.href="interna"
						}

					},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
						
						//console.log(XMLHttpRequest.responseJSON.message);
						//console.log('XHR ERROR ' + XMLHttpRequest.status);
						load("0")
						//alert( XMLHttpRequest.responseJSON.message);
						alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");
						
						///return JSON.parse(XMLHttpRequest.responseText);
						
					}
			
				
				});	
		
		}
		
	/**/
		return false;
	})
	
	

	
	
$("form#lead").submit(function(){

		var dados = $(this).serializeObject();
		
		load("1");

		
			$.ajax({
				url: 'http://meumomentophyto.com.br/api/leads',
				contentType: 'application/json',
				cache: false,
				method: 'POST',
				dataType: 'json',
				data:JSON.stringify(dados),
				success: function(data) {
					
					if(data.lead.id){
						
						alertar("Parabéns!!", "Seu cadastro foi realizado com sucesso.", "success","");
						$("form#lead")[0].reset();
	
					}
					
					//alertar("Legal", , "alert","");
					

					},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
						
						//console.log(XMLHttpRequest.responseJSON.message);
						//console.log('XHR ERROR ' + XMLHttpRequest.status);
						load("0")
						//alert( XMLHttpRequest.responseJSON.message);
						alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");
						
						///return JSON.parse(XMLHttpRequest.responseText);
						
					}
			
				
				});	
		
		
		
	/**/
		return false;
	})
	
	

	
	
	
	function checkLogin(){
				
		//console.log(getCookie("token"));
		
		if(getCookie("token") !=""){
		
		
			$("a.js-open-search-popup .center-hvert").text("LOGADO");
			$("a.js-open-search-popup").attr("href","interna");
			$("a.js-open-search-popup").addClass("btn text-green p-1");
			$("a.js-open-search-popup span").addClass("text-green");
			
			$("a.js-open-search-popup").removeClass("js-open-search-popup");
			$("ul.nav-add").addClass("logado");
			$("ul.nav-add").removeClass("scrollable");
			$("ul.nav-add").removeClass("nav-add");
			
			//$("a.js-open-search-popup .center-hvert").
		
			$(".header-content-wrapper ul.logado").detach()
			$(".header-content-wrapper ul.p-0").detach()
			$(".header-content-wrapper").append('<a href="interna" class="btn text-green p-1"> <svg class="utouch-icon utouch-icon-user cd-nav-trigger" style="height:25px;"> <use xlink:href="#utouch-icon-user"></use></svg><span class="center-hvert text-green">LOGADO</span></a>')
		}
		
			//eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MiMSJ9.4hy7bdAMwXzJ1aqKddvKvjKnUPkrsb2FoMvMiJy6l50

	}
	
	
	
	$(".widget.w-follow a").attr("target","_blank");
	$(".search-full-screen .search-standard").append('<a href="esqueciasenha" class="mt-8 btn text-green mx-auto" target="_blank"> esqueci a senha</a>');
	
	
	checkLogin();
	

})