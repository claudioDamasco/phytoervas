$(document).ready(function(){
	
	 $.fn.serializeObject = function() {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function() {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
	
	})
	

	
function deleteAllCookies() {
    var cookies = document.cookie.split(";");

    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var eqPos = cookie.indexOf("=");
        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    }
}
		
function setCookie(name, value, options = {}) {

  options = {
    path: '/',
    // add other defaults here if necessary
   // ...options
  };

  if (options.expires instanceof Date) {
    options.expires = options.expires.toUTCString();
  }

 // let updatedCookie = name + "=" + value;
  let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

  for (let optionKey in options) {
    updatedCookie += "; " + optionKey;
    let optionValue = options[optionKey];
    if (optionValue !== true) {
      updatedCookie += "=" + optionValue;
    }
  }

  document.cookie = updatedCookie;
}

//alert(decodeURIComponent(getCookie("cart")));
//deleteAllCookies()
//setCookie("cart", "");
	
function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  var user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 365);
    }
  }
}



function load(tipo){

	if(tipo == "1"){
		
		$("body").append('<div class="bodyBox load"><div class="boxCard col-lg-6 col-sm-10 col-md-10 text-center wm-content"><img src="img/waiting-icon-gif-1.jpg"></div></div>');
	
	}else if(tipo="0"){

		$(".bodyBox.load").detach();

	}

}

load("1");

function alertar(titulo, mensagem, tipo,URL=''){
	load("0");
	$("body").append('<div class="bodyBox"><div class="boxCard col-lg-6 col-sm-10 col-md-10 '+tipo+'"><span class="headerBox brd-light pt-2 pb-2 text-center divBox"><h3 class="ft-33 ft-bold pt-2 pb-2">'+titulo+'</h3></span><div class="boxBody p-2 text-center divBox"><p class="ft-22">'+mensagem+'</p></div><div class=" divBox mb-3"><span class="btn btn-'+tipo+' text-white">OK</span></div></div></div>');
	
		$(".divBox .btn").on("click",function(){
			
			$(".bodyBox").detach();
			
			
				if(URL!=""){
				
					window.location.href = URL;
				
				}
		})
	
	

}










