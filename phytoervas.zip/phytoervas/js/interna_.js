$(document).ready(function(){

	function deleteAllCookies() {
    var cookies = document.cookie.split(";");

    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var eqPos = cookie.indexOf("=");
        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    }
}
	
	if(getCookie("token")){
	
	
	
			//alert(getCookie("token"))
				//console.log(document.cookie);
				var token = getCookie("token");
				//console.log(token);
		
	
	}else{
	
			//alert("invasão");
			window.location.href="index";
	
	}
	
	
	$("form#ticket").submit(function(){
	
	
	
		var token 	= getCookie("token");
		
		var dados 	= $(this).serializeObject();
		var price 	= dados.price;
		var purchase_date = dados.purchase_date;
		var coo 	= dados.coo;
		var cnpj 	= dados.cnpj;
		
		var arquivo = $(this).find("#fileForm")[0].files[0];

			console.log("arquivo:",arquivo);
	

		  	var formData = new FormData();
		
			    formData.append("file", arquivo);
			    formData.append("price", price);
			    formData.append("purchase_date", purchase_date);
			    formData.append("coo", coo);
			    formData.append("cnpj", cnpj);
		
		 load("1");
		
		$.ajax({
				url: 'http://meumomentophyto.com.br/api/tickets',
				type: 'POST',
			    processData: false,
 			 	contentType: false,
			beforeSend: function(xhr) {
				  xhr.setRequestHeader('Authorization', 'Bearer '+token);
				},
				data: formData, 
				error: function(xhr, error, thrown) {
            		console.log("Error occurred!");
            		console.log(xhr, error, thrown);
        		},
				success: function(data) {
					
					console.log(data);
					if(data.data.status_moderation == "AGUARDANDO_MODERACAO"){
					
						load("0");
						alertar("Parabéns!!","Seu Cupom Fiscal foi cadastrado, aguarde mediação do mesmo <br /> para poder girar a ROLETA DE PRÊMIOS e ver suas chaces para <br /><h2 class='ft-30'>ganhar 1 carro 0KM.</h2> ","success","");
						$("form#ticket")[0].reset()
					
					}else{
					
						load("0");
						alertar("Ixiii!!","Algo deu errado, contate o suporte em suporte@phytoervas.com.br!","alert","");
					
					}
					
					
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
						
						console.log(XMLHttpRequest.validation);
						//console.log('XHR ERROR ' + XMLHttpRequest.status);
						load("0")
						//alert( XMLHttpRequest.responseJSON.message);
						alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert");
						
						///return JSON.parse(XMLHttpRequest.responseText);
						
					}
			});	
		
	
	
	return false;
	
	
	
	})
	
	
	
	function checkbox(input, val){
			
		
		if(val){
	 		
			$("input[name='"+input+"']:checked");
			$("input[name='"+input+"']").attr("checked",true);
			$("input[name='"+input+"']").val("true");
		}else{
		
			$("input[name='"+input+"']").val("false");
		}
	
	}
	
	
	
	
if($("form#update").length>=1){
	

				var token= getCookie("token");
		
				var dados = JSON.parse(decodeURIComponent(getCookie("dados")));
						
				
				//created_at: "2021-09-03T17:32:25.000Z"
				//updated_at: "2021-09-03T17:32:25.000Z"
		
		
				//console.log(dados.birthdate.split("T")[0])
				$("form#update").find("#nome").val(dados.name);
				$("form#update").find("#CPF").val(dados.cpf);
				$("form#update").find("#email").val(dados.email);
				$("form#update").find("input[type=date]").val(dados.birthdate.split("T")[0]);
				$("form#update").find("#telefone").val(dados.phone);
				$("form#update").find("#endereco").val(dados.address);
			
				
				checkbox("accept_news", dados.accept_news);
				checkbox("accept_regulation", dados.accept_regulation);
				checkbox("accept_whatsapp", dados.accept_whatsapp);
			
				$("form#update").submit(function(){		
					
					var formData = $(this).serializeObject();
					
					//console.log(formData);	
							
					$.ajax({
							url: 'http://meumomentophyto.com.br/api/participants',
							contentType: 'application/json',
							cache: false,
							method: 'PUT',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								data: JSON.stringify(formData), 
								error: function(xhr, error, thrown) {
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
								},
							success: function(data) {

							
								if(data.participant){
									setCookie("dados",JSON.stringify(data.participant));
									load("0");
									alertar("Parabéns!!","Seus dados foram atualizados!","success","interna.html#cadastro");
									

								}else{

									load("0");
									alertar("Ixiii!!","Algo deu errado, contate o suporte em suporte@phytoervas.com.br!","alert","");

								}


							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
					
					
					return false;
					})
		
		
		
}//FIM IF UPDATE
	
	
	
	
	
	
	$("#alterarSenha").on("click",function(){

				
					var token= getCookie("token");
					var dados = JSON.parse(decodeURIComponent(getCookie("dados")));
					//console.log(JSON.stringify({cpf:dados.cpf}));	
		
					$.ajax({
							url:'http://meumomentophyto.com.br/api/password/forgot',
							contentType: 'application/json',
							cache: false,
							method: 'POST',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								data: JSON.stringify({cpf:dados.cpf}), 
								error: function(xhr, error, thrown) {
									
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
									
								},
						
							success: function(data) {
								
								console.log(data);
								
								if(data){
									//setCookie("dados",JSON.stringify(data.participant));
									load("0");
									alertar("Ixiii!!","Algo deu errado, contate o suporte em suporte@phytoervas.com.br!","alert","");

								}else{

									load("0");
									alertar("Entendido!","Enviamos um E-mail para sua conta, com o link para alteração da sua senha!","success","");
									
								}


							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
					
					
					return false;
	
	
	})
	
	
	
	$("#esqueciasenha").on("click",function(){

				
					var token= getCookie("token");
					var dados = JSON.parse(decodeURIComponent(getCookie("dados")));
					//console.log(JSON.stringify({cpf:dados.cpf}));	
		
					$.ajax({
							url:'http://meumomentophyto.com.br/api/password/forgot',
							contentType: 'application/json',
							cache: false,
							method: 'POST',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								data: JSON.stringify({cpf:dados.cpf}), 
								error: function(xhr, error, thrown) {
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
								},
						
							success: function(data) {
								
								console.log(data);
								
								if(data){
									//setCookie("dados",JSON.stringify(data.participant));
									load("0");
									alertar("Ixiii!!","Algo deu errado, contate o suporte em suporte@phytoervas.com.br!","alert","");

								}else{

									load("0");
									alertar("Parabéns!!","Enviamos um E-mail para sua conta, com o link para alteração da sua senha!","success","");
									
								}


							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
					
					
					return false;
	
	
	})
	
	
	//alert($("#sair").length);
	
	$("#sair").on("click",function(){
	
		//alert("a");
		setCookie("token","");
		window.location.reload();
		//return false;
		
	})
	
	
	
	$("ul.scrollable").on("click",function(){
	
	})
	
	
	
	 var degree = 0, timer;
    //rotate();
	
    function rotate(elem,deg,rest,velo) {
       // console.log(elem,deg,rest) ;

		if(degree==deg){
			 
			var interval = setTimeout(function(){
				
			 		$( "body" ).removeClass("animado");
					
			 		if(rest){
							alertar("Parabéns!!","Você foi o grande sorteado do dia! Entraremos em contato com vocês nos próximos dias!","success","");
					}else{
							alertar("Aaaaaaah!!","Infelizmente Não foi dessa vez!","alert","");
							}/**/
			 },800)
			 degree=0;
			 // clearTimeout(interval);
			  clearTimeout(timer);
			  clearInterval(timer)
		 }else{
					elem.css({ WebkitTransform: 'rotate(' + degree + 'deg)'});  
					elem.css({ '-moz-transform': 'rotate(' + degree + 'deg)'});         

					timer = setTimeout(function() {

						
							
						if(degree==deg){ 
							console.log("fim");
							$( "body" ).removeClass("animado");
						  clearTimeout(timer);
						  clearInterval(timer)	   
						}else if(degree<=deg/2){
							var velo=2; //console.log(degree, velo);
						}else if(degree>=deg/2 && degree<=deg/1.5){
							var velo=5;	//console.log(degree, velo);
						}else if(degree>=deg-500){
							var velo=8;	//console.log(degree,deg/1.5, velo);
						}else if(degree == deg){
						
								
							
							 clearTimeout(timer);
			 			 clearInterval(timer)
						}
						
						console.log(degree,deg/1.5, velo);
						rotate(elem,deg,rest,velo);
								degree++
					},velo);
			 
		}
		
   			 
						
   
		
		
    }
	
	
	
	function trataData(data){
				
		
	var dados = data.split("T")[0].split("-");
	
		return dados[2]+"/"+dados[1]+"/"+dados[0]+" - "+ data.split("T")[1].replace(".000Z","");
	
	
	}
	
	
	
	
	$("#btnchances").on("click",function(a){
		
			var token= getCookie("token");
			
			load('1');
			$.ajax({
							url: 'http://meumomentophyto.com.br/api/participants/chances',
							contentType: 'application/json',
							cache: false,
							method: 'GET',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								error: function(xhr, error, thrown) {
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
								},
							success: function(data) {
								
								
								console.log(data);
								
								$("#chances h5.slider-faqs-title .numchances").html("<span class='ft-bold '>  ("+data.total+")</span>");
								
								jQuery.each(data.chances, function(key,val){
								
								
							
								$("#chances .listaschances .chance").clone().appendTo("#chances .listaschances").attr("id","chance_"+key);
								$("#chance_"+key).removeClass("chance").addClass("chanceClo").show();
									
									var created 		  = "<span class='ft-18 ft-bold'>Cadastrado</span> </br><span class='ft-24'>"+trataData(val.created_at)+"</span>",
									    quantity 		  = "<span class='ft-18 ft-bold'>Quantidade de cupons</span> </br><span class='ft-24'><strong>"+val.quantity+"</strong></span>",
									  //status 		  	  = "<span class='ft-18 ft-bold'>Código</span> </br><span class='ft-24'>"+val.status+"</span>",
										cnpj	 		  = "<span class='ft-18 ft-bold'>CNPJ</span> </br><span class='ft-24'>"+val.ticket.cnpj+"</span>",
										coo 			  = "<span class='ft-18 ft-bold'>Código</span> </br><span class='ft-24'>"+val.ticket.coo+"</span>",
										price 			  = "<span class='ft-18 ft-bold'>Valor do ticket</span> </br><span class='ft-24'>R$ "+val.ticket.price+"</span>",
										status_moderation = "<span class='ft-18 ft-bold'>Status</span> </br><span class='ft-24 "+val.ticket.status_moderation+"'>"+val.ticket.status_moderation+"</span>",							
										file_url = val.ticket.file_url;						
									console.log(file_url);
									
									//$("#chances .listaschances")
									
									
										$("#chances .listaschances").find("#chance_"+key).find(".created_ad").html(created);
										
										$("#chances .listaschances").find("#chance_"+key).find(".price").html(price);
										$("#chances .listaschances").find("#chance_"+key).find(".quantity").html(quantity);
										$("#chances .listaschances").find("#chance_"+key).find(".ticket .cnpj").html(cnpj);
										$("#chances .listaschances").find("#chance_"+key).find(".ticket .coo").html(coo);
										
										$("#chances .listaschances").find("#chance_"+key).find(".ticket .status_moderation").html(status_moderation);
									
										$("#chances .listaschances").find("#chance_"+key).find(".ticket .file").attr("href",file_url);

								})
								
								
								
								load('0');
								//console.log(data.total);
								

							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
		
		
		
		
		
		
	
	})
	
	
	
	$(".girarRoleta").on("click",function(a){
		
			var token= getCookie("token");
			
			$( "body" ).addClass("animado");
			//$( ".roleta .gira" ).addClass("animar");
			$.ajax({
							url: 'http://meumomentophyto.com.br/api/participants/roulette',
							contentType: 'application/json',
							cache: false,
							method: 'GET',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								error: function(xhr, error, thrown) {
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
								},
							success: function(data) {
								
								var rot;
								if(data.can_spin_the_rolette==true){	
									switch(data.winner){
										case false:
												var rot = 45*15;
											break;
										case true:
												var rot = 90*14;
										break;
									}

									rotate($(".roleta .gira img"),rot,data.winner,60);
									checkSpin()
								}else{
			
									
									alertar("Ixiiii!!!", "Parace que você ainda não tem chance disponível, <br /> se já enviou seu cupom, aguarde moderação do mesmo", "alert","");


								
								}
								
							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
		
		
	
	})
	
	
	function checkSpin(){
	
		
			var token= getCookie("token");
			
			$( "body" ).addClass("animado");

			$.ajax({
							url: 'http://meumomentophyto.com.br/api/participants/spin_roulette',
							contentType: 'application/json',
							cache: false,
							method: 'GET',
							dataType: 'json',
								beforeSend: function(xhr) {
							 		 xhr.setRequestHeader('Authorization', 'Bearer '+token);
								},
								error: function(xhr, error, thrown) {
									console.log("Error occurred!");
									console.log(xhr, error, thrown);
								},
							success: function(data) {
								
								
								
							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);
									load("0")
									alertar("Ixiiii!!!", XMLHttpRequest.responseJSON.message, "alert","");

								}
						});	
		
	
	
	
	
	
	}
	
	
	$("#btnpremios").on("click",function(){
	
		window.location.href=$(this).attr("href")
	
	})
	
	
	function checkWinner(){
	
	
			$.ajax({
					url: 'http://meumomentophyto.com.br/api/participants/roulette',
					contentType: 'application/json',
					cache: false,
					method: 'GET',
					dataType: 'json',
					beforeSend: function(xhr) {
								 xhr.setRequestHeader('Authorization', 'Bearer '+token);
						},
						error: function(xhr, error, thrown) {
							console.log("Error occurred!");
							console.log(xhr, error, thrown);
						},
						success: function(data) {
																		
							
							console.log(data);
							
							
								switch(data.can_spin_the_rolette){
									case true:
										$("body.interna").append("<span class='p-fixed btn-roleta '><a href='roletadepremios '><h4 class='btn py-green text-white'>Gire a Roleta do Prêmio Diário!</h4></a></span>");
										$("body.roleta").find(".qtdChance .nunChance").text("1");
										$(".btnpremios").show();
									break;
										
									case false:
										$(".btnpremios").hide();
										$("body.roleta").find(".qtdChance .nunChance").text("0")	
									break;
								}
								
							
									
								
								
							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {

									console.log(XMLHttpRequest.validation);

								}
						});	
		
	
	
	
	
	
	
	
	
	}
	checkWinner()
	
	


})